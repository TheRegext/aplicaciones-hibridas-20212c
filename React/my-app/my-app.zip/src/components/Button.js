/// Componentes funcionales

function Button(props){
    return (
        <button>{props.pedro}</button>
    )
}

export default Button